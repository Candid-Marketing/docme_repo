<?php return array (
  'admin-manage-users' => 'App\\Http\\Livewire\\AdminManageUsers',
  'user-manage' => 'App\\Http\\Livewire\\UserManage',
);