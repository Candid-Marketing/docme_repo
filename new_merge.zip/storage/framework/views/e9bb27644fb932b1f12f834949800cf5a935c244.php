<?php $__env->startSection('content'); ?>
<div class="main">
    <h1 class="mb-4">Manage Users</h1>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-manage')->html();
} elseif ($_instance->childHasBeenRendered('3chS42z')) {
    $componentId = $_instance->getRenderedChildComponentId('3chS42z');
    $componentTag = $_instance->getRenderedChildComponentTagName('3chS42z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3chS42z');
} else {
    $response = \Livewire\Livewire::mount('user-manage');
    $html = $response->html();
    $_instance->logRenderedChild('3chS42z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\docme_repo\resources\views/admin/pages/user/index.blade.php ENDPATH**/ ?>